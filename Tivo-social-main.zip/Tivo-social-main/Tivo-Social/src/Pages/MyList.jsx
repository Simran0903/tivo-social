import React from "react";
import UserMovieSection from "../componets/UserMovieSection/UserMovieSection";

function MyList() {
  return <UserMovieSection from="MyList"></UserMovieSection>;
}

export default MyList;
